package com.dicoding.githubuserapp.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.annotation.StringRes
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.dicoding.githubuserapp.R
import com.dicoding.githubuserapp.data.response.UserDetailsResponse
import com.dicoding.githubuserapp.databinding.ActivityUserDetailsBinding
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class UserDetailsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityUserDetailsBinding
    private val userDetailsViewModel by viewModels<UserDetailsViewModel>()

    companion object {
        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.tab_text_1,
            R.string.tab_text_2
        )
        const val ARG_NAME = "username"
        const val EXTRA_NAME = "extra_name"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUserDetailsBinding.inflate(layoutInflater)

        val username = intent.getStringExtra(EXTRA_NAME)
        setContentView(binding.root)



        userDetailsViewModel.isLoading.observe(this) {
            showLoading(it)
        }

        if (!username.isNullOrEmpty()) {
            userDetailsViewModel.getUserDetails(username)
        }

        userDetailsViewModel.userDetails.observe(this) {
            setDetails(it)
        }

        val sectionsPagerAdapter = SectionPagerAdapter(this)
        sectionsPagerAdapter.username = username.toString()
        val viewPager: ViewPager2 = findViewById(R.id.view_pager)
        viewPager.adapter = sectionsPagerAdapter
        val tabs: TabLayout = findViewById(R.id.tabs)
        TabLayoutMediator(tabs, viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()
        supportActionBar?.elevation = 0f

    }

    private fun setDetails(user: UserDetailsResponse) {
        binding.tvNickname.text = user.login
        binding.tvFullName.text = user.name
        Glide.with(binding.root)
            .load(user.avatarUrl)
            .circleCrop()
            .into(binding.ivProfile)
        binding.follower.text = "${user.followers} Followers"
        binding.following.text = "${user.following} Following"
    }

    private fun showLoading(isLoading: Boolean) {
        binding.loadingBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }
}